import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: MyIdApp(),
  ));
}

class MyIdApp extends StatefulWidget {
  const MyIdApp({super.key});

  @override
  _MyIdAppState createState() => _MyIdAppState();
}

class _MyIdAppState extends State<MyIdApp> {
  String name = "";
  String idNumber = "...";

  @override
  void initState() {
    super.initState();
    _initDatabaseAndFetch();
  }

  Future<void> _initDatabaseAndFetch() async {
    final database = openDatabase(
      join(await getDatabasesPath(), 'user_info.db'),
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE user_info(id INTEGER PRIMARY KEY, full_name TEXT, card_id TEXT)',
        );
      },
      version: 1,
    );

    final db = await database;

    await db.insert(
      'user_info',
      {
        'full_name': 'John Doe',
        'card_id': '123456'
      }, // Example data for insertion
      conflictAlgorithm: ConflictAlgorithm.replace,
    );

    final List<Map<String, dynamic>> result = await db.query('user_info');

    if (result.isNotEmpty) {
      setState(() {
        name = result[0]['full_name'] ?? "";
        idNumber = result[0]['card_id'] ?? "";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F2F5),
      body: Center(
        child: Container(
          width: 340,
          height: 200,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 15,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -20,
                bottom: -20,
                child: const Icon(Icons.badge),
              ),
              Padding(
                padding: const EdgeInsets.all(25.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "DIGITAL ID CARD",
                      style: TextStyle(
                          color: Colors.white70,
                          fontSize: 12,
                          letterSpacing: 2),
                    ),
                    const Spacer(),
                    const Text(
                      "NAME",
                      style: TextStyle(color: Colors.white60, fontSize: 10),
                    ),
                    Text(
                      name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.1,
                      ),
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      "IDENTIFICATION NO",
                      style: TextStyle(color: Colors.white60, fontSize: 10),
                    ),
                    Text(
                      idNumber,
                      style: const TextStyle(
                        color: Colors.cyanAccent,
                        fontSize: 18,
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
